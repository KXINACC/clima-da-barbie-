function mostrarClima() {
    document.querySelector('.intro').style.display = 'none';
    document.querySelector('.content').style.display = 'block';

    buscarClima('Natal', 'temperatura-natal', 'condicao-natal');
    buscarClima('Assu', 'temperatura-assu', 'condicao-assu');
    buscarClima('Caico', 'temperatura-caico', 'condicao-caico');
}

const apiKey = '38c5d58ec5e6455ea88173258240512';

function buscarClima(cidade, tempId, condId) {
    const url = `https://api.weatherapi.com/v1/current.json?key=${apiKey}&q=${cidade}&lang=pt`;

    fetch(url)
        .then(response => response.json())
        .then(data => {
            document.getElementById(tempId).textContent = `${data.current.temp_c}°C`;
            document.getElementById(condId).textContent = data.current.condition.text;
        })
        .catch(error => {
            console.error('Erro ao buscar os dados:', error);
        });
}